
# ZenaBot - Flert/Šaljivi Telegram AI Bot

## Kako koristiti:
1. Ubaci svoj Telegram TOKEN i OpenAI API Key kao environment variables:
   - `TOKEN` = tvoj Telegram bot token
   - `OPENAI_API_KEY` = tvoj OpenAI API key
2. Deploy na Render.com ili drugi hosting za Python.
3. Otvori Telegram i piši svom botu! 💋
